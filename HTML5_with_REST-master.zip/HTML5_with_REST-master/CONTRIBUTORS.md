# Contributors

This is the official list of the User specific HTML5 using the PLCnext REST Interface - project contributors.
<!---
Names of the original copyright holders (individuals or organizations) should be listed with a '*' in the first column. People who have contributed from an organization can be listed under the organization that actually holds the copyright for their contributions. Those individuals should have their names indented and be marked with a '-'.
-->

* Phoenix Contact GmbH & Co. KG
  - Jonas Penner
  - Gundula Breder
  - Oliver Warneke